
function run() {
    
	reproStepName=menu1value;
	colName=menu2value;
	yT=menu3value;
	// alert('posting --> reproStepName: '+reproStepName+'\t column: '+colName);
	
	sel='SELECT runnumber, stream, cast('+colName+' as number) ';
	if (document.getElementById("vsmuid").checked) sel+=', mu ';
	if (document.getElementById("useid").checked || document.getElementById("vsmuid").checked) 
		sel+=' FROM jobPerformance, runInfo WHERE jobPerformance.runNumber=runInfo.run and jobPerformance.jobProcessingStep=\''+reproStepName+'\'';
	else 
		sel += ' FROM jobPerformance WHERE jobPerformance.jobProcessingStep=\''+reproStepName+'\'';
	
	if (document.getElementById("useid").checked) sel+=' and runInfo.use=1 ';
	
	ob=document.getElementById("minrunid");
	if 	(!(isNaN(ob.value)) && ob.value!=""  ) sel += ' and runNumber >= '+ ob.value;
	ob=document.getElementById("maxrunid");
	if 	(!(isNaN(ob.value)) && ob.value!=""  ) sel += ' and runNumber <= '+ ob.value;
	
	sel += ' ORDER by stream, runnumber';
	
	document.getElementById("queryID").setAttribute("value", sel);	
	document.getElementById("maintitleID").setAttribute("value", colName + '  ' + reproStepName);
	document.getElementById("ytitleID").setAttribute("value", yT);
	// alert('posting --> '+sel);
	
    document.forms["queryFormID"].submit();
}

function showStatus(){ 
	sel="SELECT (select count(*) from ATLAS_AMI_COLL_SIZES_01_LAL.tempobjectsize) as tos, (select count(*) from ATLAS_AMI_COLL_SIZES_01_LAL.tempalgoperformance) as tap from dual";
	document.getElementById("queryID").setAttribute("value", sel);
	document.getElementById("loading").style.display="block";
    document.forms["queryFormID"].submit();
}

function cleanUp(){ 
	sel="begin ATLAS_AMI_COLL_SIZES_01_LAL.cleanup(); end;";
	document.getElementById("queryID").setAttribute("value", sel);
	document.getElementById("loading").style.display="block";
    document.forms["queryFormID"].submit();
}

function drawDBperfPlot(d1,d2,d3,d4){
    var c = document.getElementById('scatter1');
	c.height=screen.height*0.7;
	c.width=screen.width*0.7;
	var ma=0;
	for (var i=0;i<d1.length;i++) { if (d1[i]>ma) ma=d1[i]; if (d2[i]>ma) ma=d2[i];if (d3[i]>ma) ma=d3[i];if (d4[i]>ma) ma=d4[i];}
	var alg=new RGraph.Line('scatter1', d1, d2);
	alg.Set('chart.title', 'inserts/updates per 2 min.');            
	alg.Set('chart.labels', ['-24h','-21h','-18h','-15h','-12h','-9h','-6h','-3h','now']);
	alg.Set('chart.background.barcolor1', 'white');
    alg.Set('chart.background.barcolor2', 'white');
    alg.Set('chart.ymax', ma*1.1);
	alg.Set('chart.filled', true);
    alg.Set('chart.filled.range', true);
    alg.Set('chart.fillstyle', 'rgba(128,255,128,0.5)');            
	alg.Set('chart.colors', ['green']);
	alg.Set('chart.linewidth', 2);
    alg.Set('chart.gutter.left', 60);
	alg.Draw();
	var alg1=new RGraph.Line('scatter1', d3,d4);
	alg1.Set('chart.background.grid', false);
	alg1.Set('chart.background.barcolor1', 'rgba(0,0,0,0)');
    alg1.Set('chart.background.barcolor2', 'rgba(0,0,0,0)');
    alg1.Set('chart.noaxes', true);
    alg1.Set('chart.ylabels', false);
    alg1.Set('chart.ymax', ma*1.1);
	alg1.Set('chart.filled', true);
    alg1.Set('chart.filled.range', true);
	alg1.Set('chart.colors', ['red']);
    alg1.Set('chart.fillstyle', 'rgba(255,0,0,0.5)');
    alg1.Set('chart.gutter.left', 60);
	alg1.Draw();
}


function drawDBperfTable(data0,data1,data2,data3){
    
    var c = document.getElementById('scatter1');
	c.height=1;
	c.width=1;
	var tbl = document.getElementById('tableID');
	var oCaption = tbl.createCaption();
	oCaption.innerHTML = 'db performance details';
	oCaption.style.fontSize = "20px";
	oCaption.style.fontWeight = 'bold';
	oCaption.align = "top";
	var oBody=document.getElementById('tableBodyID');
	var oTHead=tbl.createTHead();
	var oRow = oTHead.insertRow(-1);
	var cellL = oRow.insertCell(0);
	cellL.appendChild(document.createTextNode("Inserts alg"));
	var cellM = oRow.insertCell(1);
	cellM.appendChild(document.createTextNode("Updates alg"));
	var cellR = oRow.insertCell(2);
	cellR.appendChild(document.createTextNode("Inserts obj"));
	var cellR1 = oRow.insertCell(3);
	cellR1.appendChild(document.createTextNode("Updates obj"));
	for (var d=0;d<data0.length;d++){
		var row = oBody.insertRow(-1);
		var cellL = row.insertCell(0);
		cellL.appendChild(document.createTextNode(data0[d]));
		var cellM = row.insertCell(1);
		cellM.appendChild(document.createTextNode(data1[d]));
		var cellR = row.insertCell(2);
		cellR.appendChild(document.createTextNode(data2[d]));
		var cellR1 = row.insertCell(3);
		cellR1.appendChild(document.createTextNode(data3[d]));
	}
}
