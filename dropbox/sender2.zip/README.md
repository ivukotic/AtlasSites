Uploader of dCache Billing DB information to xrootd collector
==============================================

This program performs query on dCache Billing DB every one minute. Query looks up amount of federation traffic. Obtained information is re-packaged into xrootd standard UPD packets and sent to a collector server AKA "UCSD collector" AKA "Matevz's collector".   

To compile the code, run:

    mvn package

to run it do:
	
	java -jar /path/to/sender-1.0-SNAPSHOT-jar-with-dependencies.jar \ 
    	<billingdb host> <billingdb user> <billingbd password> <filter> \ 
	    <collector host> <collector port> <site name>
	
all parameters are mandatory. Here's a short description:

	billingbd host: name of machine hosting your billingDB - example uct2-dc4.mwt2.org	
	billingdb user: your username to access billingDB - default is billing_ro
	collector host: atl-prod05.slac.stanford.edu 9931 
	collector port: 9931
	site name: should be in format "mwt2.org"
	filter:         this is a string (example: 'door:Xrootd-%t2-s4%') which is used to filter out any non-FAX traffic.
        Actual query executed on the DB is this:
	    "SELECT protocol, isnew, fullsize, transfersize, connectiontime FROM billinginfo WHERE datestamp>(CURRENT_TIMESTAMP - interval '1 minutes') AND initiator LIKE '"+filter+""'"
	    It is strongly advised that you try out the query yourself to test if query is getting what is needed.